package T1_Model;

public class Category {
	private int ID;
	private String Ten;
	private int Gia;
	private int SoLuong;
	private int ID_KhachHang;
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getTen() {
		return Ten;
	}
	public void setTen(String ten) {
		Ten = ten;
	}
	public int getGia() {
		return Gia;
	}
	public void setGia(int gia) {
		Gia = gia;
	}
	public int getSoLuong() {
		return SoLuong;
	}
	public void setSoLuong(int soLuong) {
		SoLuong = soLuong;
	}
	public int getID_KhachHang() {
		return ID_KhachHang;
	}
	public void setID_KhachHang(int iD_KhachHang) {
		ID_KhachHang = iD_KhachHang;
	}
}
